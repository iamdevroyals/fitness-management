import React from 'react';
import '../styles/ManageMembers.css';

const ManageMembers = () => {
  return (
    <div className="members-container">
      <h2 className="members-title">Manage Members</h2>
      <p className="members-subtitle">Here you can view, add, edit, or remove gym members.</p>

      <div className="members-actions">
        <button className="add-member-btn">+ Add Member</button>
      </div>

      <table className="members-table">
        <thead>
          <tr>
            <th>#</th>
            <th>Name</th>
            <th>Email</th>
            <th>Membership Type</th>
            <th>Joined On</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>1</td>
            <td>John Doe</td>
            <td>john@example.com</td>
            <td>Premium</td>
            <td>2025-01-10</td>
            <td>
              <button className="edit-btn">Edit</button>
              <button className="delete-btn">Delete</button>
            </td>
          </tr>
          {/* You can map more members here later */}
        </tbody>
      </table>
    </div>
  );
};

export default ManageMembers;
