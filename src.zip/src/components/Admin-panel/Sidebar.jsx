import React from 'react';
import { FiHome, FiUsers, FiSettings, FiLogOut } from 'react-icons/fi';
import { Link, useNavigate } from 'react-router-dom';
import '../styles/Sidebar.css';

const Sidebar = ({ isOpen }) => {
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem('isLoggedIn'); // Clear login status
    navigate('/login'); // Redirect to login page
  };

  return (
    <div className={`sidebar ${isOpen ? 'expanded' : 'collapsed'}`}>
      <nav className="sidebar-nav">
        <div className="sidebar-logo">
          {isOpen ? <h1>Fitness Management</h1> : <span>F</span>}
        </div>

        <ul className="sidebar-menu">
          <li>
            <Link to="/" className="sidebar-link">
              <FiHome className="sidebar-icon" />
              {isOpen && <span>Dashboard</span>}
            </Link>
          </li>
          <li>
            <Link to="/members" className="sidebar-link">
              <FiUsers className="sidebar-icon" />
              {isOpen && <span>Manage Members</span>}
            </Link>
          </li>
          <li>
            <Link to="/classes" className="sidebar-link">
              <FiSettings className="sidebar-icon" />
              {isOpen && <span>Manage Classes</span>}
            </Link>
          </li>
          <li>
            <Link to="/workouts" className="sidebar-link">
              <FiSettings className="sidebar-icon" />
              {isOpen && <span>Workout Plans</span>}
            </Link>
          </li>
        </ul>

        <button className="sidebar-link logout-btn" onClick={handleLogout}>
          <FiLogOut className="sidebar-icon" />
          {isOpen && <span>Logout</span>}
        </button>
      </nav>
    </div>
  );
};

export default Sidebar;
