import React from 'react';
import '../styles/ManageClasses.css';

const ManageClasses = () => {
  return (
    <div className="classes-container">
      <h2 className="classes-title">Manage Classes</h2>
      <p className="classes-subtitle">Add, edit, or remove fitness classes and manage their schedules.</p>

      <div className="classes-actions">
        <button className="add-class-btn">+ Add Class</button>
      </div>

      <table className="classes-table">
        <thead>
          <tr>
            <th>#</th>
            <th>Class Name</th>
            <th>Trainer</th>
            <th>Time</th>
            <th>Days</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>1</td>
            <td>Yoga Basics</td>
            <td>Jane Smith</td>
            <td>7:00 AM - 8:00 AM</td>
            <td>Mon, Wed, Fri</td>
            <td>
              <button className="edit-btn">Edit</button>
              <button className="delete-btn">Delete</button>
            </td>
          </tr>
          {/* Add more class rows as needed */}
        </tbody>
      </table>
    </div>
  );
};

export default ManageClasses;
