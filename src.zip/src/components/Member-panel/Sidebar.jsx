import React from 'react';
import {
  FiHome,
  FiCalendar,
  FiBarChart2,
  FiLogOut,
} from 'react-icons/fi';
import { Link, useNavigate } from 'react-router-dom';
import '../styles/sidebar.css'; // Assuming you have a CSS file for styling

const Sidebar = ({ isOpen }) => {
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.clear();
    navigate('/login');
  };

  return (
    <div className={`sidebar ${isOpen ? 'expanded' : 'collapsed'}`}>
      <nav className="sidebar-nav">
        <div className="sidebar-logo">
          {isOpen ? <h1>Fitness Member</h1> : <span>F</span>}
        </div>

        <ul className="sidebar-menu">
          <li>
            <Link to="/member" className="sidebar-link">
              <FiHome className="sidebar-icon" />
              {isOpen && <span>Dashboard</span>}
            </Link>
          </li>
          <li>
            <Link to="/member/classes" className="sidebar-link">
              <FiCalendar className="sidebar-icon" />
              {isOpen && <span>My Classes</span>}
            </Link>
          </li>
          <li>
            <Link to="/member/workouts" className="sidebar-link">
              <FiBarChart2 className="sidebar-icon" />
              {isOpen && <span>My Workouts</span>}
            </Link>
          </li>
        </ul>

        <button className="sidebar-link logout-btn" onClick={handleLogout}>
          <FiLogOut className="sidebar-icon" />
          {isOpen && <span>Logout</span>}
        </button>
      </nav>
    </div>
  );
};

export default Sidebar;
