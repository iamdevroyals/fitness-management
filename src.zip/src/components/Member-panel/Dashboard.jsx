import React from 'react';
import '../styles/Dashboard.css'; // Assuming you have a CSS file for styling

const Dashboard = () => (
  <div className="dashboard">
    <h2>Welcome, Member!</h2>
    <p>Select an option from the sidebar to get started.</p>
  </div>
);

export default Dashboard;
