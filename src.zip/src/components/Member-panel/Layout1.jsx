// src/components/Member-panel/Layout1.jsx
import React from 'react';
import { Outlet } from 'react-router-dom';
import Header from './Header1';
import Sidebar from './Sidebar';
import '../styles/Layout.css'; // Assuming you have a CSS file for styling

const MemberLayout = () => {
  return (
    <div className="layout-container">
      <Sidebar />
      <div className="main-content">
        <Header />
        <main className="content-area">
          <Outlet /> {/* MemberDashboard will render here */}
        </main>
      </div>
    </div>
  );
};

export default MemberLayout;
