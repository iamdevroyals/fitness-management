// src/auth/Login.jsx
import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import './login.css';

const Login = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  // ⏩  If already logged in, skip this page
  useEffect(() => {
    const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    if (isLoggedIn && currentUser) {
      navigate(`/${currentUser.role}`, { replace: true });
    }
  }, [navigate]);

  const handleLogin = (e) => {
    e.preventDefault();

    // 1️⃣ Hard-coded admin account
    const isAdmin =
      email.trim().toLowerCase() === 'admin@example.com' &&
      password === 'admin123';

    // 2️⃣ Registered users from Signup
    const users = JSON.parse(localStorage.getItem('users')) || [];
    const matchedUser = users.find(
      (user) =>
        user.email.trim().toLowerCase() === email.trim().toLowerCase() &&
        user.password === password
    );

    if (isAdmin || matchedUser) {
      const role = isAdmin ? 'admin' : matchedUser.role || 'member';

      // Save auth state for ProtectedRoute
      localStorage.setItem('isLoggedIn', 'true');
      localStorage.setItem(
        'currentUser',
        JSON.stringify({ email: email.trim(), role })
      );

      // Redirect by role
      navigate(role === 'admin' ? '/admin' : '/member', { replace: true });
    } else {
      setError('Invalid email or password');
    }
  };

  return (
    <div className="login-container">
      <form className="login-form" onSubmit={handleLogin}>
        <h2>Fitness Login</h2>

        {error && <p className="error-text">{error}</p>}

        <input
          type="email"
          placeholder="Email"
          value={email}
          required
          onChange={(e) => setEmail(e.target.value)}
        />

        <input
          type="password"
          placeholder="Password"
          value={password}
          required
          onChange={(e) => setPassword(e.target.value)}
        />

        <button type="submit">Login</button>

        <p className="note-text">
          Default admin:&nbsp;
          <strong>admin@example.com / admin123</strong>
        </p>

        <p className="note-text">
          New user? <Link to="/signup">Sign up here</Link>
        </p>
      </form>
    </div>
  );
};

export default Login;
